a = input("Enter your input1 in String: ")
b = input("Enter your input2 in String: ")

print(id(a))
print(id(b))
if id(a) == id(b):
    print("True")
else:
    print("False")
