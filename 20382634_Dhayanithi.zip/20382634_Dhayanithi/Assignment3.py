a = input("Enter the input")
print(a)
i =0
List = []
while(i<len(a)):
   # print("The ASCII value of input %c = %d" %(a[i], ord(a[i])))
    List.append(ord(a[i]))
    i = i+1

List.sort()
print("The highest ASCII value is: ", max(List))
print("The lowest ASCII value is: ", min(List))
