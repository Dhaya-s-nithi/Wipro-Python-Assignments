import re
#8. Tokenize the below paragraph into a list of words excluding the stop words using list comprehensions

str1 =""" Guido van Rossum, best known as the Python programming language author, was born 31 January 1956 in Netherlands. In Python community, Van Rossum is known as a BDFL (Benevolent Dictator for Life), which means that he continues to oversee Python development process, and always making decisions where necessary. He worked at Google from 2005 till 7 2012, where he spent half of his time developing Python programming language. In 2013, Guido started working for Dropbox Guido van Rossum was born and grew up in Netherlands, where he received the Master’s degree in the mathematics and computer science from University of Amsterdam in 1982. Guido later worked for various research institutes, such as Dutch Centrum Wiskunde & Informatica (CWI), United States National Institute of Standards and Technology (NIST), and also Corporation for National Research Initiatives (CNRI). 

Stop Words = { “a”, “the”, “is”, “are”, “an”, “as”, “at”, “be”} """

print(str1)

stopWords = {"a", "the", "is", "are", "an", "as", "at", "be"}

strList = re.split(r'[,-;.()\s]\s*', str1)
new_list = [i for i in strList if i not in stopWords]
print("\n",new_list)
