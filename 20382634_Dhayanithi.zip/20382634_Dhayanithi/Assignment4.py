dict = {'a' :'á','e' :'é','i' :'í','o' :'ó','u' :'ú', }
d = "a speech sound produced by human beings when the breath flows out through the mouth without being blocked by the teeth, tongue, or lips"

print("Before: ", d)

for i,j in dict.items():
    d =d.replace(i,j)

print("After: ", d)