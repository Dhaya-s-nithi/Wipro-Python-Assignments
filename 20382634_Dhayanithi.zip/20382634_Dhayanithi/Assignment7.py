d = [i for i in range(300, 500)]
h = [d for d in d if True in[True for divisor in range(2,9) if d % divisor == 0]]
print(h)