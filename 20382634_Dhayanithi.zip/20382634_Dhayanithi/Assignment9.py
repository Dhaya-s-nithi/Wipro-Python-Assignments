from itertools import count
class Person:
    count =0
    def __init__(self, fname, lname):
        Person.count +=1
        self.fname = fname
        self.lname = lname
    def return_count(self):
        return count

p1 = Person("Shashi", "Reddy")
p2 = Person("Bobby", "Goud")
p3 = Person("Aishu", "Rathod")
p4 = Person("Tony", "Stark")
print("Number of Person Instances", Person.count)