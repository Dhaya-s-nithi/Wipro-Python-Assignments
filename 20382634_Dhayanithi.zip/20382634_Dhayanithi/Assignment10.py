from datetime import date

today = date.today()
class TodaysDate:
    month = {1:"January",2:"February",3:"March",4:"April",5:"May",6:"June",7:"July",8:"August",9:"September",10:"October",11:"November",12:"December"}
    def __init__(self, today):
        self.day = today.day
        self.month = today.month

    def __str__(self):
        return f'The {today.day} of the {self.month[today.month]} in the year {today.year}'

    def __repr__(self):
        return f'The {today.day} of the {self.month[today.month]} in the year {today.year}'

    @staticmethod
    def get_current_day(self):
        print(self)
        print(repr(self))

obj = TodaysDate(today)
TodaysDate.get_current_day(obj)