a = input("Enter the first input: ")
print(a)
b = int(input("Enter the second input: "))
print(b)


# Using f-string
print(f"The first input is {a} and the second input is {b}")

# Using Format
print("Using {a} version {b}".format(a = a,b = b))
