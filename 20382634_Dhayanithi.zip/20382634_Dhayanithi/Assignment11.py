def generate_pid(pid):
    val = pid
    yield val


class Product:
    def __init__(self, pid, name, price):
        pObj = generate_pid(pid)
        self.pid = pObj.__next__()
        self.name = name
        self.price = price


product_list = []


class Depot:
    def add_item(self):
        name_list = [dic['name'] for dic in product_list]
        new = {}
        while True:
            pname = input("Enter the name of the product: ")
            if pname not in name_list:
                break
            print(pname, " already exists!")

        pid = input("Enter Product ID: ")
        price = int(input("Enter the price of the product: "))
        print("------------------------------")
        obj = Product(pid, pname, price)
        new["id"] = obj.pid
        new["name"] = pname
        new["price"] = price
        product_list.append(new)

    def remove_item(self, name):
        name_list = [dic['name'] for dic in product_list]
        if name in name_list:
            num = name_list.index(name)
            del product_list[num]
            print("Deletion Successful!")

        else:
            print("Name not found to delete.")

    def display_item(self):
        print("Products List")
        for val in product_list:
            print("----------------------")
            for i, j in val.items():
                print(i, ":", j)

    def find_product(self, name):
        name_list = [dic['name'] for dic in product_list]
        if name in name_list:
            num = name_list.index(name)
            print(product_list[num])
        else:
            print("Name not found to delete.")

    def sort_by_price(self):
        print("Sorting By Price")
        print(sorted(product_list, key=lambda item: item['price'], reverse=True))


objD = Depot()
objD.add_item()
objD.add_item()
objD.add_item()
print(product_list)
objD.remove_item(input("Enter the Item name to delete: "))
print(product_list)
objD.display_item()
objD.find_product(input("Enter Product Name: "))
objD.sort_by_price()
