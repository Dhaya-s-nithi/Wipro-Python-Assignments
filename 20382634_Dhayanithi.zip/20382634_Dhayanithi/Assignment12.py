class ListOfStrings:
    list = []
    def append(self, val):
        try:
            if type(val) is str:
                self.list.append(val.title())
                print(self.list)

            else:
                raise TypeError("Only string are allowed")

        except TypeError as e:
            print("TypeError: ", e)

obj = ListOfStrings()
obj.append("Hello")
obj.append("Python is easy to understand")
obj.append(234)
obj.append("Tony Stark")
obj.append(143)


