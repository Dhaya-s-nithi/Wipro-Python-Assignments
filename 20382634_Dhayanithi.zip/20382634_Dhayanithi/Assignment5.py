d = input("Enter the string input: ")
print("String in utf-16 format ", d.encode('utf-16'))